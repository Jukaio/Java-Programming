package com.jukaio.jumpandrun;

public abstract class MusicID
{
    public static int LEVEL_ONE        = -1;
    public static int LEVEL_TWO        = -1;
    public static int LEVEL_THREE      = -1;
}
