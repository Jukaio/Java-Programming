package com.jukaio.jumpandrun;

public abstract class SoundID
{
    public static int GET_HIT          = -1;
    public static int GET_COIN         = -1;
}
