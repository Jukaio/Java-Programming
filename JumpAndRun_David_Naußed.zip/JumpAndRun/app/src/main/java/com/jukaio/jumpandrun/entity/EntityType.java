package com.jukaio.jumpandrun.entity;

public enum EntityType
{
    UNKNOWN,
    PLAYER,
    COLLECT,
    LETHAL
}
