package com.jukaio.jumpandrun;

public class Spike
{
}
