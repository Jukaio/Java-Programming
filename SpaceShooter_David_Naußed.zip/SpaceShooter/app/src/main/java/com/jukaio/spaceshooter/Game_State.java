package com.jukaio.spaceshooter;

public enum Game_State
{
    GAMEPLAY,
    GAME_OVER
}
