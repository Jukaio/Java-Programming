package com.jukaio.spaceshooter.game_entities;

public enum Entity_Type
{
    UNKNOWN,
    PLAYER,
    BULLET,
    UFO,
    HUNTER,
    POWER_UP
}
