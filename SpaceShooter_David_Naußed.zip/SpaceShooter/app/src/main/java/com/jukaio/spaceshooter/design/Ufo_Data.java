package com.jukaio.spaceshooter.design;

public class Ufo_Data
{
    public int m_pool_size;
    public float m_scale;
    public float m_speed;
    public int m_max_hp;
    public int m_points;
}
