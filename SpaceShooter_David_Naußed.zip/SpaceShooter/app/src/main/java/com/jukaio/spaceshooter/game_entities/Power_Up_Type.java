package com.jukaio.spaceshooter.game_entities;

public enum Power_Up_Type
{
    DUAL_GUN,
    HP_PLUS
}
