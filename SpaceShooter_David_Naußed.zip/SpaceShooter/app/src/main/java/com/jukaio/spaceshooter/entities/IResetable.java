package com.jukaio.spaceshooter.entities;

// Just wanted to test interfaces
// Pretty cool for implementations on the side
public interface IResetable
{
    void reset();
}
