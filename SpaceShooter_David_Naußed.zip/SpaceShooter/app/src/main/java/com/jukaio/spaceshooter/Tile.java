package com.jukaio.spaceshooter;

public class Tile
{
    public boolean has_unit;
    
    public Tile()
    {
        has_unit = false;
    }
    
}
